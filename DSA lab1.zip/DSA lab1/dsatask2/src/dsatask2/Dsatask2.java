/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsatask2;

/**
 *
 * @author M Muzamil
 */
public class Dsatask2 {
    public static void main(String[] args) {
    int[] arr={5,15,25,35,45,55};
   for(int i=0; i<arr.length; i++){
       System.out.println("Element at index "+i+":"+arr[i]);  
    }
    
}
}