/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsatask6;
import java.util.Scanner;
/**
 *
 * @author M Muzamil
 */
public class Dsatask6 {
public static void main(String[] args) {
   Scanner input=new Scanner(System.in);
    String s1=input.nextLine();
int left=0;
int right=s1.length()-1;
boolean palindrome=true;
while(left<=right){
    if(s1.charAt(left)!=s1.charAt(right)){
        palindrome=false;
        break;
    }
    else{
        left++;
        right--;
    }
}
if(palindrome==true){
    System.out.println("It is palindreme");
}else{
    System.out.println("Not a palindrome");
}
}
   
}
