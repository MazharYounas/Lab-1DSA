/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsatask8;
import java.util.Scanner;
import java.util.Arrays;
/**
 *
 * @author M Muzamil
 */
public class Dsatask8 {
    public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
        System.out.println("Input string 1");
        String s1=input.nextLine();
        System.out.println("Input string 2");
        String s2=input.nextLine();
        char[] charary1=s1.toCharArray();
        char[] chararay2=s2.toCharArray();
        Arrays.sort(charary1);
        Arrays.sort(chararay2);
        if(Arrays.equals(charary1, chararay2)){
            System.out.println("This is anagram");
        }else{
            System.out.println("not an anagram");
        }
    }
    
}
