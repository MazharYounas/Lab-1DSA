/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsatask7;

/**
 *
 * @author M Muzamil
 */
public class Dsatask7 {
    public static void main(String[] args) {
     int[] arr={13,26,39,52,65};
     int index=4;
        System.out.println("Element at "+index+" :"+arr[index]);
   int[] arr2={4,6,2,8,10};
   for(int i=0; i<arr2.length-1; i++){
       if(arr2[i]==8){
           System.out.println("Element 8 fount at index: "+i);
       } }
    int[] arr3={11,22,33,44,55};
    int target=33;
    int left=0;
    int right=arr3.length-1;
    while(left<=right){
        int middle=left+(right-left)/2;
        if(arr3[middle]==target){
            System.out.println("element found at index"+middle);
            break;
            
        }else if(arr3[middle]<target){
            left=middle+1;
        }
        else{
            right=middle-1;
        }
    }
    }
    
}
